declare module 'image-data-uri';
